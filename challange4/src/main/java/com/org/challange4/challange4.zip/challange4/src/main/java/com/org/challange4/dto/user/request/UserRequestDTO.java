package com.org.challange4.dto.user.request;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UserRequestDTO {
    private String username;
    private String emailAddress;
    private String password;
}
