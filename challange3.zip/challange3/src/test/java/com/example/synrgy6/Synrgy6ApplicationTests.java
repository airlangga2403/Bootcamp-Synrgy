package com.example.synrgy6;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Synrgy6ApplicationTests {

	@Test
	void contextLoads() {
	}

}
