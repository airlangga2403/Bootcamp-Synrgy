package com.binarfud.proplayer.challange5.dto.order.response;

import com.binarfud.proplayer.challange5.models.Orders;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class OrderInfoDTO {
    private Orders order;
}
