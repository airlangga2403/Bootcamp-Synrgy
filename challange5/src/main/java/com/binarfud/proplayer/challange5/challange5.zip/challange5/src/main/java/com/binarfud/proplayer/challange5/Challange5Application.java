package com.binarfud.proplayer.challange5;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Challange5Application {

	public static void main(String[] args) {
		SpringApplication.run(Challange5Application.class, args);
	}

}
